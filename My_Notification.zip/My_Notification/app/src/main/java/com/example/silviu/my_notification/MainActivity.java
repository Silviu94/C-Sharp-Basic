package com.example.silviu.my_notification;

import android.app.Notification;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    //
    private EditText editNotificationTitle;
    private EditText editNotificationContent;
    private Button sendNotification;

    private NotificationMethods notificationMethods;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Associate objects to corresponding layout views
        editNotificationTitle = findViewById(R.id.editText);
        editNotificationContent = findViewById(R.id.editText1);
        sendNotification = findViewById(R.id.button);

        notificationMethods = new NotificationMethods(this);

        //Create an OnClick listener for "Send notification" button
        sendNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            //Method to be executed when "Send notification" button is clicked
            public void onClick(View view) {
                sendNotificationOnButtonClick(editNotificationTitle.getText().toString(), editNotificationContent.getText().toString());
            }
        });
    }

    public void sendNotificationOnButtonClick(String notificationTitle, String notificationContent) {
        NotificationCompat.Builder notificationBuilder = notificationMethods.getNotificationChannel(notificationTitle, notificationContent);
        notificationMethods.getManager().notify(1, notificationBuilder.build());


    }
}
