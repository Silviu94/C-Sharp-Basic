package com.example.silviu.my_notification;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

public class NotificationMethods extends ContextWrapper {

    //Set channel id
    private static final String CHANNEL_ID = "channelid";
    //Set channel name
    private static final String CHANNEL_NAME = "Channel";


    private NotificationManager notificationManager;

    //Define constructor for NotificationMethods class
    public NotificationMethods(Context base) {
        super(base);

        //Only if used emulator is related to API 26 or higher, this part will be executed
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createChannels();
        }
    }

    @TargetApi(Build.VERSION_CODES.O)
    public void createChannels() {

        //Create android channel(Channel allows android app developers to group notifications)
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
        // Sets the notification light color for notifications posted to this channel
        channel.setLightColor(R.color.yellowGreen);
        // Sets whether notifications posted to this channel appear on the lockscreen or not
        channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);

        getManager().createNotificationChannel(channel);
    }

    public NotificationManager getManager() {

        //Set NotificationManager if none was setted previous.
        if (notificationManager == null) {
            notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        return notificationManager;
    }

    public NotificationCompat.Builder getNotificationChannel(String notificationTitle, String notificationContent) {

        //Create notification by specifying the used channel, title, contenct and icon.
        return new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID)
                .setContentTitle(notificationTitle)
                .setContentText(notificationContent)
                .setSmallIcon(R.drawable.ic_one);

    }

}
